# ckeditor-syntaxhighlight
A plugin for CKEditor 4+ that enables code syntax highlighting.

* CKEditor 4 support and german language added by s.ziegltrum
* French language added by [Tristan Jahier](http://tristan-jahier.fr)
