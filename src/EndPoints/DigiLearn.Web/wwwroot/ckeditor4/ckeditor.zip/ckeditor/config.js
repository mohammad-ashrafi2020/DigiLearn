CKEDITOR.editorConfig = function (config) {
    config.extraPlugins = 'codesnippet';
    config.codeSnippet_theme = 'monokai_sublime';
    config.language = 'fa';
    config.filebrowserImageUploadUrl = '/Upload/Article';
    config.preset = 'full';
};
